<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class EnsureAdministrator
{
    public function handle(Request $request, Closure $next)
    {
        abort_unless($request->user()?->isAdministrator(), 403);

        return $next($request);
    }
}
